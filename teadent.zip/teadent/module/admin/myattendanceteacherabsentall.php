<?php  
include_once('main.php');
$sid=$_REQUEST['id'];
$attendmon = "SELECT DISTINCT (date) FROM attendance WHERE  date not in (select DISTINCT(date) from attendance where attendedid='$sid' )";
$resmon = mysqli_query($link,$attendmon);
echo "<tr> <th>Absent All Dates:</th></tr>";
while($r=mysqli_fetch_array($link,$resmon))
{
 echo "<tr><<td>",$r['date'],"</td></tr>";

}
?>
