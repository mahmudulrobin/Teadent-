# School-Management-System
### Welcome to School-Management-System Git Page.
This Web Application developed using php,ajax,jquery.Custom Lay Architecture

###*Admin features
* * modify his admin  information with picture.
* *create, delete, and update teacher, staff, student, parent account information with picture.
* *add, delete, and update salary for employee (teacher, staff).
* * add, delete, and update class, course, and exam schedule.
* * add, delete, and update attendance employee (teacher, staff).
* (Student attendance will give by teacher)
* *generate report of each class Student passed/failed % result to evaluate teacher performance.
* *generate report Staff and Teacher (leaves and missing day’s (number of missing days per month) performance report).
* *Monthly Total Salary and payable salary Each Employee (individual) and All Employee (Total).
* *Admin can Search teacher, staff, student, parent by id.
* *teacher can search by course.
* *student can search by also class and course.
* *show all unpaid student list this month.

###Teacher features
* *update his/her account information with picture (no id and name).
* *add, delete, and update Report for his/her class student.
* * add, delete, and update student marks with his assigned courses.
* * add, delete, and update attendance student attendance.
*          (Student attendance will give by teacher)
* *generate report of each class Student passed/failed % result to evaluate his/her Class.
* *generate report (leaves and missing day’s (number of missing days per month)) for check salary and his/her evaluation.
* *Monthly Total Salary and payable and omitted salary for absence.
* *Teacher can Search student, parent by id.
* *teacher can search by course his/her course student list.
* *student can search by also his/her class and course.
* *show all student list absent days this month.

###Student features
* *see his/her account information with picture (no edit).
* *See his/her Class all class with course teacher information, section, result.
* *student can see  his/her  current class and course Exam Schedule.
* * student see all attendance  days this month.

###Staff features
* *see account information with picture.
* *modify contact information and password.
* *see salary monthly and payable this month.
* *Attendance like this month absent present.

###Parents features
* *see account information with picture.
* *modify contact information and password.
* *see his/her students report.
* *Attendance like this month absent present his students.
* * see his/her students Grade.
* *see his/her student’s payment.

### Authors and Contributors

### 1. Prosen Ghosh
* [Prosen Ghosh GitHub](https://github.com/Prosen-Ghosh)
* [Prosen Ghosh Facebook](https://www.facebook.com/prosenghosh25)

### 2. Ahmed Habibullah Rifat (Namespaceahr)
* [Namespaceahr GitHub](https://github.com/namespaceahr/)
* [Namespace ahr Facebook](https://www.facebook.com/namespaceahr)

### 3. Khurshedul Barid

* [Khurshedul Barid Facebook](https://www.facebook.com/md.barid)

# School-Management-System-With-PHP
